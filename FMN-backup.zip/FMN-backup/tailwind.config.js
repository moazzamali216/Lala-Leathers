/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*",
    "./node_modules/flowbite/**/*.js"
  ],
  theme: {
    extend: {
      fontFamily: {
        Proxima : [ 'Proxima Nova', 'sans-serif']
      }
    },
  },
  plugins: [
    require('flowbite/plugin')
  ],
}
