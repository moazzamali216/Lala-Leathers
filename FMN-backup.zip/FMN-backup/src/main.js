
$(function() {
    $(window).on("scroll", function() {
        if($(window).scrollTop() > 100) {
            $(".header__top").addClass("nav__active");
            $(".change-clr").addClass('btn-black');
            $(".change-clr").removeClass('btn-white');

        } else {
           $(".header__top").removeClass("nav__active");
           $(".change-clr").removeClass('btn-black');
           $(".change-clr").addClass('btn-white');

        }
    });
});

$(function(){
    $('.login , .signup, .edit-acc').on('click', function(){
        $('#authentication-modal,#signup-modal,#defaultModal').addClass('animate__slideInDown')
    })
})
document.addEventListener('DOMContentLoaded', function () {
    new Swiper('.swiper-container', {
      loop: true,
      slidesPerView: 1,
      spaceBetween: 32,
      autoplay: {
        delay: 8000,
      },
      breakpoints: {
        640: {
          centeredSlides: true,
          slidesPerView: 1,
        },
        1024: {
          centeredSlides: false,
          slidesPerView: 1,
        },
      },
      navigation: {
        nextEl: '.next-button',
        prevEl: '.prev-button',
      },
    })
})

